import { NbMenuItem } from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [
 
 
  {
    title: 'Forms',
    icon: 'edit-2-outline',
    children: [
      {
        title: 'course enrollment',
        link: '/pages/forms/inputs',
      },
      {
        title: 'trining code generation',
        link: '/pages/forms/layouts',
      },
    
    
    ],
  },
];
